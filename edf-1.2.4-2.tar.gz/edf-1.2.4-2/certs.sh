#!/bin/bash

CACERT=$(kubectl -n $NAMESPACE get secret $SECRETNAME -o json | jq -r '.data["ca.crt"]')
CAKEY=$(kubectl -n $NAMESPACE get secret $SECRETNAME -o json | jq -r '.data["ca.key"]')
TLSCERT=$(kubectl -n $NAMESPACE get secret $SECRETNAME -o json | jq -r '.data["tls.crt"]')
TLSKEY=$(kubectl -n $NAMESPACE get secret $SECRETNAME -o json | jq -r '.data["tls.key"]')

CERTIFICATE=$(kubectl -n $NAMESPACE get secret $SECRETNAME -o json | jq -r '.data["tls.crt"]' | base64 --decode)
KEYCERT=$(kubectl -n $NAMESPACE get secret $SECRETNAME -o json | jq -r '.data["tls.key"]' | base64 --decode)
