#!/bin/bash

# Load environnement varaibles
. $(pwd)/env/env-api.sh

echo '************************ START SECRET API ************************'
if kubectl get secret "$MASTER_SECRET" -n "$NAMESPACE" &> /dev/null; then
    echo "SECRET '$MASTER_SECRET' exists in namespace '$NAMESPACE'."
else
    echo "SECRET '$MASTER_SECRET' does not exist in namespace '$NAMESPACE'."    
    kubectl -n "$NAMESPACE" create secret generic $MASTER_SECRET \
        --from-literal=dcpkey="$MASTER_DCPKEY" \
        --from-literal=dcphashed="$MASTER_DCPHASHED" \
        --from-literal=password="$PGS_PASSWORD"
fi
echo '************************ END SECRET API ************************'


if [[ $MASTER_USERWX == "true" ]]; then
#MASTER PVC
echo '************************ START VOLUME API ************************'
if kubectl get pvc "$MASTER_PVC" -n "$NAMESPACE" &> /dev/null; then
    echo "PVC '$MASTER_PVC' exists in namespace '$NAMESPACE'."
else
    echo "PVC '$MASTER_PVC' does not exist in namespace '$NAMESPACE'."

    sed -e "s#{{MASTER_PVC}}#$MASTER_PVC#g;\
    s#{{NAMESPACE}}#$NAMESPACE#g;\
    s#{{COMMONLABELS_PVC}}#$COMMONLABELS_PVC#g;\
    s#{{MASTER_SHARED_STORAGECLASSANNOTATION}}#$MASTER_SHARED_STORAGECLASSANNOTATION#g;\
    s#{{MASTER_SHARED_STORAGECLASSNAME}}#$MASTER_SHARED_STORAGECLASSNAME#g;\
    s#{{MASTER_SHARED_SIZE}}#$MASTER_SHARED_SIZE#g;\
    s#{{MASTER_ACCESS_MODE}}#$MASTER_ACCESS_MODE#g;\
    s#{{MASTER_SHARED_SIZE}}#$MASTER_SHARED_SIZE#g;" $yamltemplate/master-pvc-template.yaml > $yamldestination/master-pvc.yaml

    kubectl -n "$NAMESPACE" apply -f $yamldestination/master-pvc.yaml
fi
echo '************************ END VOLUME API ************************'

sleep 5
fi

#MASTER
echo '************************ START ' $PREFIX ' API ************************'
if [[ $createdcpapi == "true" ]]; then
    if kubectl get sts $releasemaster -n $NAMESPACE &> /dev/null; then
        echo '============================= ' $PREFIX ' API ALREADY INSTALLED ============================='
    else
        echo '=================================== CREATING' $PREFIX  ' API ==================================='
        sed -e "s#{{MASTER_NAME}}#$MASTER_NAME#g;\
        s#{{NAMESPACE}}#$NAMESPACE#g;\
        s#{{RGPDLINK}}#$RGPDLINK#g;\
        s#{{MASTER_USERWX}}#$MASTER_USERWX#g;\
        s#{{MASTER_GRANTPC_RBAC}}#$MASTER_GRANTPC_RBAC#g;\
        s#{{PREFIX}}#$PREFIX#g;\
        s#{{MASTER_PORT}}#$MASTER_PORT#g;\
        s#{{MASTER_AFFINITYENABLED}}#$MASTER_AFFINITYENABLED#g;\
        s#{{MASTER_AFFINITY}}#$MASTER_AFFINITY#g;\
        s#{{MASTER_ANTIAFFINITY}}#$MASTER_ANTIAFFINITY#g;\
        s#{{MASTER_REQUIRED}}#$MASTER_REQUIRED#g;\
        s#{{MASTER_TOPOLOGY}}#$MASTER_TOPOLOGY#g;\
        s#{{MASTER_PODMANAGEMENTPOLICY}}#$MASTER_PODMANAGEMENTPOLICY#g;\
        s#{{MASTER_PVC}}#$MASTER_PVC#g;\
        s#{{MASTER_ACCESS_MODE}}#$MASTER_ACCESS_MODE#g;\
        s#{{NINXCLASS}}#$NINXCLASS#g;\
        s#{{ISOPENSHIFT}}#$ISOPENSHIFT#g;\
        s#{{CLUSTERDOMAIN}}#$CLUSTERDOMAIN#g;\
        s#{{STORAGECLASSNAME}}#$STORAGECLASSNAME#g;\
        s#{{SECRETNAME}}#$SECRETNAME#g;\
        s#{{MASTER_REPLICACOUNT}}#$MASTER_REPLICACOUNT#g;\
        s#{{MASTER_ALLINONEPOD}}#$MASTER_ALLINONEPOD#g;\
        s#{{MASTER_API_VERSION}}#$MASTER_API_VERSION#g;\
        s#{{IMAGEPULLSECRET}}#$IMAGEPULLSECRET#g;\
        s#{{PULLPOLICY}}#$PULLPOLICY#g;\
        s#{{MASTER_LOGLEVEL}}#$MASTER_LOGLEVEL#g;\
        s#{{MASTER_REPLICAS}}#$MASTER_REPLICAS#g;\
        s#{{MASTER_ANTIAFFINITY}}#$MASTER_ANTIAFFINITY#g;\
        s#{{PREFIX}}#$PREFIX#g;\
        s#{{MASTER_WORK}}#$MASTER_WORK#g;\
        s#{{MASTER_SHARED_SIZE}}#$MASTER_SHARED_SIZE#g;\
        s#{{MASTER_SHARED_STORAGECLASSNAME}}#$MASTER_SHARED_STORAGECLASSNAME#g;\
        s#{{MASTER_SHARED_STORAGECLASSANNOTATION}}#$MASTER_SHARED_STORAGECLASSANNOTATION#g;\
        s#{{MASTER_WORK_SIZE}}#$MASTER_WORK_SIZE#g;\
        s#{{MASTER_WORK_PATH}}#$MASTER_WORK_PATH#g;\
        s#{{MASTER_WORK_SUBPATH}}#$MASTER_WORK_SUBPATH#g;\
        s#{{MASTER_PVC}}#$MASTER_PVC#g;\

        s#{{MASTER_HOSTALIASES}}#$MASTER_HOSTALIASES#g;\
        s#{{MASTER_DNSCONFIG}}#$MASTER_DNSCONFIG#g;\
        s#{{MASTER_HIDELOG}}#$MASTER_HIDELOG#g;\

        s#{{PGS_SERVICENAME}}#$PGS_SERVICENAME#g;\

        s#{{REGISTRY}}#$REGISTRY#g;\
        s#{{MASTER_REPOSITORY}}#$MASTER_REPOSITORY#g;\
        s#{{MASTER_VERSION}}#$MASTER_VERSION#g;\

        s#{{COMMONLABELS}}#$COMMONLABELS#g;\
        s#{{COMMONANNOTATIONS}}#$COMMONANNOTATIONS#g;\

        s#{{MASTER_ENABLE_AUTOSCALING}}#$MASTER_ENABLE_AUTOSCALING#g;\
        s#{{MASTER_MINREPLICAS}}#$MASTER_MINREPLICAS#g;\
        s#{{MASTER_MAXREPLICAS}}#$MASTER_MAXREPLICAS#g;\
        s#{{MASTER_TARGETCPU}}#$MASTER_TARGETCPU#g;\
        s#{{MASTER_TARGETMEMORY}}#$MASTER_TARGETMEMORY#g;\

        s#{{RUNASUSER}}#$RUNASUSER#g;\
        s#{{READONLYROOTFILESYSTEM}}#$READONLYROOTFILESYSTEM#g;\
        s#{{MASTER_SERVICE_ACCOUNT}}#$MASTER_SERVICE_ACCOUNT#g;\
        s#{{MASTER_CLUSTER_ROLE}}#$MASTER_CLUSTER_ROLE#g;\
        s#{{MASTER_NAMESPACES}}#$MASTER_NAMESPACES#g;\

        s#{{MASTER_SSL_ENABLED}}#$MASTER_SSL_ENABLED#g;\
        s#{{MASTER_SSL_AUTOGENERATED}}#$MASTER_SSL_AUTOGENERATED#g;\
        s#{{INIT_IMAGE}}#$INIT_IMAGE#g;\
        s#{{MASTER_KEYSTORE_PATH}}#$MASTER_KEYSTORE_PATH#g;\
        s#{{MASTER_KEYSTORE_PASSWORD}}#$MASTER_KEYSTORE_PASSWORD#g;\
        s#{{MASTER_TRUSTSTORE_PATH}}#$MASTER_TRUSTSTORE_PATH#g;\
        s#{{MASTER_INIT_REQUESTCPU}}#$MASTER_INIT_REQUESTCPU#g;\
        s#{{MASTER_INIT_REQUESTMEMORY}}#$MASTER_INIT_REQUESTMEMORY#g;\
        s#{{MASTER_INIT_LIMITCPU}}#$MASTER_INIT_LIMITCPU#g;\
        s#{{MASTER_INIT_LIMITMEMORY}}#$MASTER_INIT_LIMITMEMORY#g;\

        s#{{MASTER_PGS_CONNECTION_TIMEOUT}}#$MASTER_PGS_CONNECTION_TIMEOUT#g;\
        s#{{MASTER_PGS_MINIMUMIDLE}}#$MASTER_PGS_MINIMUMIDLE#g;\
        s#{{MASTER_PGS_MAXIMUMPOOLSIZE}}#$MASTER_PGS_MAXIMUMPOOLSIZE#g;\
        s#{{MASTER_PGS_IDLETIMEOUT}}#$MASTER_PGS_IDLETIMEOUT#g;\
        s#{{MASTER_PGS_MAXLIFETIME}}#$MASTER_PGS_MAXLIFETIME#g;\
        s#{{MASTER_PGS_AUTOCOMMIT}}#$MASTER_PGS_AUTOCOMMIT#g;\

        s#{{LDAP_SECURED}}#$LDAP_SECURED#g;\
        s#{{LDAP_FACTORY}}#$LDAP_FACTORY#g;\
        s#{{LDAP_URL}}#$LDAP_URL#g;\
        s#{{LDAP_PRINCIPAL}}#$LDAP_PRINCIPAL#g;\
        s#{{LDAP_GIVENNAME}}#$LDAP_GIVENNAME#g;\
        s#{{LDAP_SHORTNAME}}#$LDAP_SHORTNAME#g;\
        s#{{LDAP_EMAIL}}#$LDAP_EMAIL#g;\
        s#{{LDAP_GROUP}}#$LDAP_GROUP#g;\
        s#{{LDAP_UID}}#$LDAP_UID#g;\
        s#{{LDAP_VIEWALLATTRIBUTES}}#$LDAP_VIEWALLATTRIBUTES#g;\
        s#{{LDAP_FILTERSEARCH}}#$LDAP_FILTERSEARCH#g;\

        s#{{LDAP_SEARCHMETHOD}}#$LDAP_SEARCHMETHOD#g;\
        s#{{LDAP_CANGETATTRIBUTE}}#$LDAP_CANGETATTRIBUTE#g;\
        s#{{LDAP_SCOPELEVEL}}#$LDAP_SCOPELEVEL#g;\
        s#{{LDAP_AUTHENTICATIONTYPE}}#$LDAP_AUTHENTICATIONTYPE#g;\
        s#{{LDAP_BINDDN}}#$LDAP_BINDDN#g;\
        s#{{LDAP_BINDPASSWORD}}#$LDAP_BINDPASSWORD#g;\
        s#{{LDAP_ATTRIBUTES}}#$LDAP_ATTRIBUTES#g;\
        s#{{LDAP_BINDFILTERSEARCH}}#$LDAP_BINDFILTERSEARCH#g;\

        s#{{MASTER_EXTRAS_FILES}}#$MASTER_EXTRAS_FILES#g;\
        s#{{MASTER_EXTRAS_HOSTNAMES}}#$MASTER_EXTRAS_HOSTNAMES#g;\

        s#{{MASTER_XMS}}#$MASTER_XMS#g;\
        s#{{MASTER_XMX}}#$MASTER_XMX#g;\
        s#{{MASTER_REQUESTCPU}}#$MASTER_REQUESTCPU#g;\
        s#{{MASTER_REQUESTMEMORY}}#$MASTER_REQUESTMEMORY#g;\
        s#{{MASTER_LIMITCPU}}#$MASTER_LIMITCPU#g;\
        s#{{MASTER_LIMITMEMORY}}#$MASTER_LIMITMEMORY#g;\

        s#{{MASTER_PERSISTENCE_ENABLED}}#$MASTER_PERSISTENCE_ENABLED#g;\
        s#{{MASTER_PERSISTENCE_SIZE}}#$MASTER_PERSISTENCE_SIZE#g;\
        
        s#{{MASTER_CLUSTER_ROLE}}#$MASTER_CLUSTER_ROLE#g;\
        
        s#{{PODWATCHER_CLEANPODS}}#$PODWATCHER_CLEANPODS#g;\
        s#{{PODWATCHER_REQUESTCPU}}#$PODWATCHER_REQUESTCPU#g;\
        s#{{PODWATCHER_REQUESTMEMORY}}#$PODWATCHER_REQUESTMEMORY#g;\
        s#{{PODWATCHER_LIMITCPU}}#$PODWATCHER_LIMITCPU#g;\
        s#{{PODWATCHER_LIMITMEMORY}}#$PODWATCHER_LIMITMEMORY#g;\
        
        s#{{PODWATCHER_NAMESPACES}}#$PODWATCHER_NAMESPACES#g;\

        s#{{ENABLEOSROOT}}#$ENABLEOSROOT#g;\
        s#{{ENABLEINGRESS}}#$ENABLEINGRESS#g;\
        s#{{INGRESSHOSTNAME}}#$INGRESSHOSTNAME#g;\
        
        s#{{MASTER_INGRESS_HOSTNAME}}#$MASTER_INGRESS_HOSTNAME#g;\
        s#{{MASTER_INGRESS_PATH}}#$MASTER_INGRESS_PATH#g;\
        
        s#{{PGS_USERNAME}}#$PGS_USERNAME#g;\
        s#{{PGS_PASSWORD}}#$PGS_PASSWORD#g;\
        s#{{PGS_DATABASE}}#$PGS_DATABASE#g;\
        s#{{PGS_REPLICATION_ARCHITECTURE}}#$PGS_REPLICATION_ARCHITECTURE#g;\
        s#{{PGS_REPLICACOUNT}}#$PGS_REPLICACOUNT#g;\
        s#{{PGS_REPLICATION_REPOSITORY}}#$PGS_REPLICATION_REPOSITORY#g;\
        s#{{PGS_REPLICATION_VERSION}}#$PGS_REPLICATION_VERSION#g;\
        
        s#{{HEALTH_HEARTBEAT}}#$HEALTH_HEARTBEAT#g;\
        s#{{HEALTH_DELAY}}#$HEALTH_DELAY#g;\
        s#{{HEALTH_REQUESTCPU}}#$HEALTH_REQUESTCPU#g;\
        s#{{HEALTH_REQUESTMEMORY}}#$HEALTH_REQUESTMEMORY#g;\
        s#{{HEALTH_LIMITCPU}}#$HEALTH_LIMITCPU#g;\
        s#{{HEALTH_LIMITMEMORY}}#$HEALTH_LIMITMEMORY#g;\

        s#{{MASTER_ENABLECERTMANAGER}}#$MASTER_ENABLECERTMANAGER#g;\
        s#{{MASTER_ISSUERTYPE}}#$MASTER_ISSUERTYPE#g;\
        s#{{MASTER_ISSUERGROUP}}#$MASTER_ISSUERGROUP#g;\
        s#{{MASTER_ISSUER}}#$MASTER_ISSUER#g;\
        s#{{MASTER_DURATION}}#$MASTER_DURATION#g;\
        s#{{MASTER_RENEWBEFORE}}#$MASTER_RENEWBEFORE#g;\

        s#{{CACERT}}#$CACERT#g;\
        s#{{CAKEY}}#$CAKEY#g;\
        s#{{TLSCERT}}#$TLSCERT#g;\
        s#{{TLSKEY}}#$TLSKEY#g;" $yamltemplate/master-template.yaml > $yamldestination/master.yaml

        echo "" >> $yamldestination/master.yaml
        echo "certificate: |" >> $yamldestination/master.yaml
        echo "$CERTIFICATE" | while IFS= read -r line; do
            echo "  $line" >> $yamldestination/master.yaml
        done
        echo "key: |-" >> $yamldestination/master.yaml
        echo "$KEYCERT" | while IFS= read -r line; do
            echo "  $line" >> $yamldestination/master.yaml
        done
        if [[ $template == "false" ]]; then
            helm -n $NAMESPACE upgrade --cleanup-on-fail --install $releasemaster $repodir/master-api --values $yamldestination/master.yaml
        fi
        #kubectl -n $NAMESPACE wait --for=condition=available --timeout=600s deployment.apps/master-proxy
        echo '=================================== ' $PREFIX  ' API CREATED ==================================='
    fi
else
    echo '=================================== ' $PREFIX  ' API DISABLED==================================='
fi

echo '************************ END ' $PREFIX ' API ************************'
echo ''
echo ''