#!/bin/bash

# Load environnement varaibles
. ./env.sh
. ./certs.sh

#MASTER
echo '************************ START ' $PREFIX ' AUTO SCALER ************************'
if [[ $createdcpautoscaler == "true" ]]; then
    if kubectl get sts $releaseautoscaler -n $NAMESPACE &> /dev/null; then
        echo '============================= ' $PREFIX ' AUTO SCALER ALREADY INSTALLED ============================='
    else
        echo '=================================== CREATING' $PREFIX  ' AUTO SCALER ==================================='
sed -e "s#{{SCALER_OPERATOR_REPLICAS}}#$SCALER_OPERATOR_REPLICAS#g;\
s#{{SCALER_METRICS_SERVER}}#$SCALER_METRICS_SERVER#g;\
s#{{SCALER_WEBHOOKS}}#$SCALER_WEBHOOKS#g;\
s#{{SCALER_OPERATOR_CPU_REQUEST}}#$SCALER_OPERATOR_CPU_REQUEST#g;\
s#{{SCALER_OPERATOR_MEM_REQUEST}}#$SCALER_OPERATOR_MEM_REQUEST#g;\
s#{{SCALER_OPERATOR_CPU_LIMIT}}#$SCALER_OPERATOR_CPU_LIMIT#g;\
s#{{SCALER_OPERATOR_MEM_LIMIT}}#$SCALER_OPERATOR_MEM_LIMIT#g;\
s#{{SCALER_METRICSSERVER_CPU_REQUEST}}#$SCALER_METRICSSERVER_CPU_REQUEST#g;\
s#{{SCALER_METRICSSERVER_MEM_REQUEST}}#$SCALER_METRICSSERVER_MEM_REQUEST#g;\
s#{{SCALER_METRICSSERVER_CPU_LIMIT}}#$SCALER_METRICSSERVER_CPU_LIMIT#g;\
s#{{SCALER_METRICSSERVER_MEM_LIMIT}}#$SCALER_METRICSSERVER_MEM_LIMIT#g;\
s#{{SCALER_WEBHOOKS_CPU_REQUEST}}#$SCALER_WEBHOOKS_CPU_REQUEST#g;\
s#{{SCALER_WEBHOOKS_MEM_REQUEST}}#$SCALER_WEBHOOKS_MEM_REQUEST#g;\
s#{{SCALER_WEBHOOKS_CPU_LIMIT}}#$SCALER_WEBHOOKS_CPU_LIMIT#g;\
s#{{RUNASUSER}}#$RUNASUSER#g;\
s#{{REGISTRY}}#$REGISTRY#g;\
s#{{REPOSITORY}}#$REPOSITORY#g;\
s#{{SCALER_VERSION}}#$SCALER_VERSION#g;\
s#{{PULLPOLICY}}#$PULLPOLICY#g;\
s#{{IMAGEPULLSECRET}}#$IMAGEPULLSECRET#g;\
s#{{SCALER_WEBHOOKS_MEM_LIMIT}}#$SCALER_WEBHOOKS_MEM_LIMIT#g;" $yamltemplate/autoscaler-template.yaml > $yamldestination/autoscaler.yaml

        if [[ $template == "false" ]]; then
            helm -n $NAMESPACE upgrade --cleanup-on-fail --install $releaseautoscaler $repodir/dcp-autoscaler --values $yamldestination/autoscaler.yaml
        fi
        echo '=================================== ' $PREFIX  ' AUTO SCALER CREATED ==================================='
    fi
else
    echo '=================================== ' $PREFIX  ' AUTO SCALER DISABLED==================================='
fi
echo '************************ END ' $PREFIX ' AUTO SCALER ************************'
echo ''