#!/bin/bash

. $(pwd)/env/env.sh

kubectl -n $NAMESPACE delete secret $SECRETNAME

kubectl -n $NAMESPACE create secret generic $SECRETNAME \
  --from-file=ca.crt=certs/ca.crt \
  --from-file=ca.key=certs/ca.key \
  --from-file=tls.crt=certs/tls.crt \
  --from-file=tls.key=certs/tls.key \
  --from-file=keycloak.crt=certs/keycloak.crt \
  --from-file=keycloak.key=certs/keycloak.key