#!/bin/bash

# Load environnement varaibles
. $(pwd)/env/env-api.sh

echo '************************ START ' $PREFIX ' REPOS ************************'
if [[ $createdcpapi == "true" ]]; then
echo '=================================== CREATING' $PREFIX  ' MODEL ==================================='
sed -e "s#{{MASTER_NAME}}#$MASTER_NAME#g;\
s#{{NAMESPACE}}#$NAMESPACE#g;\
s#{{CLUSTERDOMAIN}}#$CLUSTERDOMAIN#g;\
s#{{PGS_SERVICENAME}}#$PGS_SERVICENAME#g;\
s#{{PGS_DATABASE}}#$PGS_DATABASE#g;\
s#{{PGS_USERNAME}}#$PGS_USERNAME#g;\
s#{{PGS_PASSWORD}}#$PGS_PASSWORD#g;\
s#{{MASTER_KEYSTORE_PATH}}#$MASTER_KEYSTORE_PATH#g;\
s#{{MASTER_TRUSTSTORE_PATH}}#$MASTER_TRUSTSTORE_PATH#g;\
s#{{MASTER_KEYSTORE_PASSWORD}}#$MASTER_KEYSTORE_PASSWORD#g;" $yamltemplate/master-repos-template.yaml > $yamldestination/master-repos.yaml

sed -e "s#{{MASTER_NAME}}#$MASTER_NAME#g;\
s#{{COMMONLABELSHEIGHT}}#$COMMONLABELSHEIGHT#g;\
s#{{IMAGEPULLSECRET}}#$IMAGEPULLSECRET#g;\
s#{{REGISTRY}}#$REGISTRY#g;\
s#{{PGS_REPLICATION_REPOSITORY}}#$PGS_REPLICATION_REPOSITORY#g;\
s#{{PGS_REPLICATION_VERSION}}#$PGS_REPLICATION_VERSION#g;\
s#{{PULLPOLICY}}#$PULLPOLICY#g;\
s#{{RUNASUSER}}#$RUNASUSER#g;\
s#{{READONLYROOTFILESYSTEM}}#$READONLYROOTFILESYSTEM#g;\
s#{{MASTER_REPOSITORY}}#$MASTER_REPOSITORY#g;\
s#{{MASTER_VERSION}}#$MASTER_VERSION#g;\
s#{{MASTER_PVC}}#$MASTER_PVC#g;" $yamltemplate/master-repos-job-template.yaml > $yamldestination/master-repos-job.yaml

if [[ $template == "false" ]]; then
kubectl -n $NAMESPACE apply -f $yamldestination/master-repos.yaml
sleep 3
kubectl -n $NAMESPACE delete -f $yamldestination/master-repos-job.yaml
sleep 3
kubectl -n $NAMESPACE apply -f $yamldestination/master-repos-job.yaml
fi

echo '=================================== ' $PREFIX  ' REPOS DEPLOYED ==================================='
else
    echo '=================================== ' $PREFIX  ' REPOS DISABLED==================================='
fi

echo '************************ END ' $PREFIX ' REPOS ************************'