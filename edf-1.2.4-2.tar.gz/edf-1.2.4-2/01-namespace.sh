#!/bin/bash

# Load environnement varaibles
. ./env.sh

# Create namespace
echo '************************ START DCP NAMESPACE ************************'
if [[ $createnamepace == "true" ]]; then
    echo '----------------Create DCP namespace--------------------'
    if kubectl get namespaces | grep -q $NAMESPACE; then   
        echo 'DCP namespace already exist'
    else
        if [[ $template == "false" ]]; then
            kubectl create ns $NAMESPACE
        fi
        echo 'DCP namespace created'
    fi
else
    echo '----------------IGNORE CREATING NAMESPACE--------------------'
fi
echo '************************ END DCP NAMESPACE ************************'
echo ''
echo ''